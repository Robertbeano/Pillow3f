from PIL import Image
from itertools import product
from math import cos, sin, atan, radians, degrees, pi, tan, acos, asin
import numpy, random

class RenderPipeline:
    def __init__(self, window_w, window_h):
        self.parent_map = Image.new('RGBA', (window_w, window_h))
        self.bitmap = self.parent_map.load()
        self.height = window_h
        self.width = window_w
        self.camera = [[0, 0, -20], [0, 0, 0]]
        self.fov = 45

    def save(self, file_type, location, name):
        self.parent_map.save(location + '/' + name + '.' + file_type)
        
    def subdivide(self, v1, v2, v3):
        avgs = [sum(x)/3 for x in list(zip(v2, v2, v3))]
        return [(avgs, v1, v2), (avgs, v2, v3), (avgs, v1, v3)]

    def pixel(self, x, y, color_data):
        x, y = int(x), int(y)
        if x in range(-self.width//2+1, self.width//2-1) and y in range(-self.height//2+1, self.height//2-1):
            self.bitmap[int(x+(self.width/2)), int((-y)+(self.height/2))] = color_data

    def project(self, vert, cam, camera_rotation, fov):
        Cx, Cy, Cz, Sx, Sy, Sz = [cos(radians(x)) for x in camera_rotation] + [sin(radians(x)) for x in camera_rotation]
        rotation_matrix = numpy.dot(numpy.dot(
            [[1, 0, 0],
             [0, Cx, -Sx],
             [0, Sx, Cx]],

            [[Cy, 0, Sy],
             [0,  1, 0],
             [-Sy, 0, Cy]]),

            [[Cz, -Sz, 0],
             [Sz, Cz, 0],
             [0, 0, 1]])
        
        f = (fov*(45/26))/45
        new_vert = numpy.subtract(cam, vert)
        dx, dy, dz = numpy.dot(rotation_matrix, new_vert)
        dz = dz * f
        aspect = self.width/self.height
        return (dx/dz)*self.width, (dy/dz)*self.height*aspect
    
    def softmax(self, items):
        return [j/sum(items) for j in items]
    
    def angle(self, *args):
        if len(args) == 3:
            v1, v2, v3 = args
            refrence = sorted([v1, v2, v3], key=lambda x: x[1])[::-1]
            point1 = numpy.add(refrence[0], 0)
            point2 = numpy.add(numpy.divide(numpy.add(refrence[1], refrence[2]), 2), 0)
            Ax, Ay, Az = point1
            Bx, By, Bz = point2
            Cx, Cy, Cz = refrence[1]
            Dx, Dy, Dz = refrence[2]
            if Cz-Dz == 0:
                slopex = 999999
            else:
                slopex = (Cx-Dx)/(Cz-Dz)

            if Cx-Dx == 0:
                slopey = 999999
            else:
                slopey = (Cy-Dy)/(Cx-Dx)

            if Ax-Bz == 0:
                slopez = 0
            else:
                slopez = (Az-Bz)/(Ay-By)
            return round(90-degrees(atan(slopex)), 3), round(degrees(atan(slopey)), 3), round(degrees(atan(slopez)), 3)

    def vertex(self, vert, color):
        x, y = self.project(vert, self.camera[0], self.camera[1], self.fov)
        self.pixel(x, y, color)

    def distance2(self, x1, y1, x2, y2):
        return ((x1-x2)**2+(y1-y2)**2)**(1/2)
        
    def triangle(self, verts, color):
        verts = sorted(verts, key=lambda x: x[1])
        for j,x in enumerate(verts):
            for k,y in enumerate(x):
                verts[j][k] = round(y, 4)
                
        Ax, Ay = self.project(verts[0], self.camera[0], self.camera[1], self.fov)
        Bx, By = self.project(verts[1], self.camera[0], self.camera[1], self.fov)
        Cx, Cy = self.project(verts[2], self.camera[0], self.camera[1], self.fov)
        if int(Ax)==int(Bx):
            Ax-=2
        if int(Bx)==int(Cx):
            Bx-=2
        if int(Cx)==int(Ax):
            Cx-=2
        if int(Ay)==int(By):
            Ay-=2
        if int(By)==int(Cy):
            By-=2
        if int(Cy)==int(Ay):
            Cy-=2
        m = (By-Cy)/(Bx-Cx)
        equation = lambda x: m*(x-Bx)+By
        d_factor = (abs(By-Cy)/abs(Bx-Cx))*4
        if Cx>Bx:
            for x in range(int(Bx*d_factor), int(Cx*d_factor)+1):
                cm = (Ay-equation(x/d_factor))/(Ax-(x/d_factor))
                c_equation = lambda x: cm*(x-Ax)+Ay
                if x/d_factor>Ax:
                    for cx in range(int(Ax*2), int((x/d_factor)*2)+1):
                        Aperc=(self.distance2(cx/2, c_equation(cx/2), Ax, Ay)+1)**-1
                        Bperc=(self.distance2(cx/2, c_equation(cx/2), Bx, By)+1)**-1
                        Cperc=(self.distance2(cx/2, c_equation(cx/2), Cx, Cy)+1)**-1
                        c_col = list(self.softmax([Aperc, Bperc, Cperc]))
                        c_col = [int(round(x)) for x in list(numpy.add(numpy.add(numpy.multiply(color[0], c_col[0]), numpy.multiply(color[1], c_col[1])), numpy.multiply(color[2], c_col[2])))]
                        self.pixel(cx/2, c_equation(cx/2), tuple(c_col))
                        
                if Ax>x/d_factor:
                    for cx in range(int((x/d_factor)*2), int(Ax*2)+1):
                        Aperc=(self.distance2(cx/2, c_equation(cx/2), Ax, Ay)+1)**-1
                        Bperc=(self.distance2(cx/2, c_equation(cx/2), Bx, By)+1)**-1
                        Cperc=(self.distance2(cx/2, c_equation(cx/2), Cx, Cy)+1)**-1
                        c_col = list(self.softmax([Aperc, Bperc, Cperc]))
                        c_col = [int(round(x)) for x in list(numpy.add(numpy.add(numpy.multiply(color[0], c_col[0]), numpy.multiply(color[1], c_col[1])), numpy.multiply(color[2], c_col[2])))]
                        self.pixel(cx/2, c_equation(cx/2), tuple(c_col))
                        
        if Bx>Cx:
            for x in range(int(Cx*d_factor), int(Bx*d_factor)+1):
                cm = (Ay-equation(x/d_factor))/(Ax-(x/d_factor))
                c_equation = lambda x: cm*(x-Ax)+Ay
                if x/d_factor>Ax:
                    for cx in range(int(Ax*2), int((x/d_factor)*2)+1):
                        Aperc=(self.distance2(cx/2, c_equation(cx/2), Ax, Ay)+1)**-1
                        Bperc=(self.distance2(cx/2, c_equation(cx/2), Bx, By)+1)**-1
                        Cperc=(self.distance2(cx/2, c_equation(cx/2), Cx, Cy)+1)**-1
                        c_col = list(self.softmax([Aperc, Bperc, Cperc]))
                        c_col = [int(round(x)) for x in list(numpy.add(numpy.add(numpy.multiply(color[0], c_col[0]), numpy.multiply(color[1], c_col[1])), numpy.multiply(color[2], c_col[2])))]
                        self.pixel(cx/2, c_equation(cx/2), tuple(c_col))
                        
                if Ax>x/d_factor:
                    for cx in range(int((x/d_factor)*2), int(Ax*2)+1):
                        Aperc=(self.distance2(cx/2, c_equation(cx/2), Ax, Ay)+1)**-1
                        Bperc=(self.distance2(cx/2, c_equation(cx/2), Bx, By)+1)**-1
                        Cperc=(self.distance2(cx/2, c_equation(cx/2), Cx, Cy)+1)**-1
                        c_col = list(self.softmax([Aperc, Bperc, Cperc]))
                        c_col = [int(round(x)) for x in list(numpy.add(numpy.add(numpy.multiply(color[0], c_col[0]), numpy.multiply(color[1], c_col[1])), numpy.multiply(color[2], c_col[2])))]
                        self.pixel(cx/2, c_equation(cx/2), tuple(c_col))

    def rotate(self, vert, rot):
        Cx, Cy, Cz, Sx, Sy, Sz = [cos(radians(x)) for x in rot] + [sin(radians(x)) for x in rot]
        return numpy.dot(numpy.dot(numpy.dot(
        [[1, 0, 0],
         [0, Cx, -Sx],
         [0, Sx, Cx]],
        
        [[Cy, 0, Sy],
         [0, 1, 0],
         [-Sy, 0, Cy]]),

        [[Cz, -Sz, 0],
         [Sz, Cz, 0],
         [0, 0, 1]]), vert)
if __name__ == '__main__':
    for x in range(5):
        a, b, c = [-2, 0, 1], [-4, 0, -1], [-3, 12, 0]
        shape1 = [a, b, c]
        a, b, c = [1, 0, 1], [-1, 0, -1], [0, 1.5, 0]
        shape2 = [a, b, c]
        Pipe = RenderPipeline(600, 800)
        Pipe.camera = [[0, 0, -20], [0, x*(45/5), 0]]
        Pipe.triangle(shape1, [[150, 75, 0, 255], [150, 75, 0, 255], [0, 75, 200, 255]])
        Pipe.triangle(shape2, [[255, 0, 0, 128], [0, 255, 0, 255], [0, 0, 255, 255]])
        Pipe.save('png', 'C:/Users/Basse/Desktop/Ack', 'newRendered_image%s' % x)
        print(Pipe.angle(a, b, c))

"""
for u in range(3600):
    for x, y, z in product(range(-1, 1), range(-1, 1), range(-1, 1)):
        vx, vy = Pipe.project([x*2+1, y*2+1, z*2+1], [0, 0, -5], [0, 0, u/100], 45)
        Pipe.pixel(int(vx), int(vy), (int(u*(255/3600)), int(u*(255/3600)), int(u*(255/3600)), 255))



Pipe.parent_map.show()
"""
